from distutils.core import setup

setup(
name="FGMultiSource",
version="1.0",
description="multi-source experiment",
author="viki",
py_modules=["formula_test.fixed_f_vanilla","formula_test.loading"]
)
